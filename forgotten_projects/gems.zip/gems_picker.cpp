/*      +++++++++++
        +         +
        +   GEMS  +
        +         +
        +++++++++++

        wojciech bruzda

        20130310 [0022] ...
        20130314 [0012] vector of pointers
        20130315 [0012] recursion and function pointers... ---> new method of marking the region
        20130316 [0005] merging with ALLEGRO [I think it's been fucked up...]
        20130317 [0022] mouse
        20130318 [0022] (int c0(int))
        20130319 [0022] sound
        20130320 [0022] minor fixes
        20130321 [0022] minor fixes
        20130322 [0005] tiles replaced by diamonds
        20130323 [0005] title: REGION_MARKER
        20130323 [0022] [x]-button
        20130327 [0022] two playing modes
        20130328 [0022] title: GEMS PICKER, tiles and diamonds are called "gems" from now on
        20130401 [0022] template: "a421cgb_gp.hpp"
        20130402 [0005] refactoring

        ALLEGRO OPTIONS for DEV-C++ 4.9.9.2
        -----------------------------------
        When callin compiler:
                -DALLEGRO_STATICLINK
        When callin linker:
                -lalleg_s -lgdi32 -ldxguid -lole32 -ldinput -lddraw -lwinmm -ldsound
                check box: Do not create a console window

        TO BE DONE:

        0. what about the deconstructor[s] when ERROR_HANDLER(char*) is being triggered?
        1. rescaling tiles (gems)
        2. transparency bitmaps ---> allegro5+ ?
        4. when game window is out of focus and then comes back for playing, k/b buffer fails
        5. MAKE SCORE!!! for MODE_9

        */

////////////////////////////////////////////////////////////////////////////////

//
// game specifications
//
#define _cell_size 60;
#define _cell_space 7;
#define _x_origin 1;
#define _y_origin 2;

const char * GAME_WINDOW_CAPTION = "GEMS PICKER | v20130402 | wojciech bruzda";

const int sx_size = 800; // screen size for ALLEGRO
const int sy_size = 600;

#define GAME_MODE_3 3;
#define GAME_MODE_9 9;

////////////////////////////////////////////////////////////////////////////////

#include "a421cgb_gp.hpp"

#define CALL_PREVIOUS_FUNCTION(i){\
        if (fp_stack.size() == 0) { return; }\
        void (GEMS_PICKER::*fp)(int);\
        fp = this->fp_stack.back();\
        fp_stack.pop_back();\
        (this->*fp)(i);\
        }

////////////////////////////////////////////////////////////////////////////////

class GEMS_PICKER : public GAME_BOARD {
    int * T; // temporary array
    int GAME_MODE;
    int active_gem; // hold the colour number of the gem that is clicked
    int r_max;
    int c_max;
public:
    std::vector<void (GEMS_PICKER::*)(int)> fp_stack; // vector of pointers to functions cx(int) for x = 0, 1, 2, 3

    void c0(int); // trace functions marking interior of the region, see description below...
    void c1(int);
    void c2(int);
    void c3(int);

    void RESET();
    void PLAY();
    void toggle_mode();
    void delete_marked_region();
    void check_board();

    void tt_print(void); // obsolete

    GEMS_PICKER();
    virtual ~GEMS_PICKER() { delete[] T; };
};

GEMS_PICKER::GEMS_PICKER() : GAME_BOARD() {
    r_max = 9; // fixed values
    c_max = 12;

    T = new int[r_max * c_max];
    std::srand(std::time(0));
}

void GEMS_PICKER::toggle_mode( {
    while (!key[KEY_ESC]) {
        if (close_button_pressed == 1) { break; }
        if (key[KEY_3]) { GAME_MODE = GAME_MODE_3; RESET(); PLAY(); rest(200); clear_keybuf(); }
        if (key[KEY_9]) { GAME_MODE = GAME_MODE_9; RESET(); PLAY(); rest(200); clear_keybuf(); }

        blit(screen_game_01, screen_buffer, 0, 0, 0, 0, screen_game_01 -> w, screen_game_01 -> h);
        blit(screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
    }
}

/*      PLAYING SCHEME
        --------------

        WELCOME_SCREEN:            GAME_MODE_3:               GAME_MODE_9:
        +------------[-][ ][x]     +------------[-][ ][x]     +------------[-][ ][x]
        |                   |      |                   |      |                   |
        |  mode [3] -------------->|  [SPACE]=[RESET]  |      | [SPACE]=[RESET]   |
        |                   |<--------[ESC]            |      |                   |
        |  mode [9] ---------------|                   |----->|                   |
  EXIT<----[ESC]            |<-----|                   |--------[ESC]             |
        +-------------------+      +-------------------+      +-------------------+

        [x]-button is active all the time => [exit] */

void GEMS_PICKER::PLAY() {
    int allegro_mx = 0, allegro_my = 0, allegro_mb = 0; // allegro: mouse [x], [y] and its [b]utton

    clear_to_color(screen_buffer, makecol(0, 0, 0));

    while (!key[KEY_ESC]) {
        if (key[KEY_SPACE]) { RESET(); }
        if (close_button_pressed == 1) { break; }

        if (allegro_mx != mouse_x || allegro_my != mouse_y || allegro_mb != mouse_b) {
            allegro_mx = mouse_x;
            allegro_my = mouse_y;
            allegro_mb = mouse_b;
        }

        cell_hover(allegro_mx, allegro_my); // rest(100) when no hovering...
        if (allegro_mb == 1) {
            while (allegro_mb == mouse_b) {} // prevent dragging mouse when mouse button is down
            for (int cell_index = 0; cell_index<r_max*c_max; cell_index++) {
                if ((get_cx(cell_index) < allegro_mx) && (allegro_mx < get_cx(cell_index) + cell_size) &&
                    (get_cy(cell_index) < allegro_my) && (allegro_my < get_cy(cell_index) + cell_size)) {
                    active_gem = get_value(cell_index);
                    if (active_gem > 0) { // prevent proceeding when clicked on empty cell
                        c0(cell_index);
                        delete_marked_region();
                        draw();
                        check_board();
                        break;
                    }
                }
            }
            clear_keybuf();
        }
        blit(screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
    }
    clear_to_color(screen_buffer, makecol(0, 0, 0));
}

void GEMS_PICKER::RESET() { // draw gems at random on the GAME_ARRAY to be displayed on GAME_BOARD using CELL :)
    for (int i = 0; i < r_max * c_max; i++) {
        T[i] = 0;
        set_value(i, 1 + rand() % GAME_MODE);
    }
}

void GEMS_PICKER::tt_print(void) { // text-terminal-oriented control printout [obsolete]
    for (int i = 0; i < r_max * c_max; i++) {
        !(i % c_max) ?
            std::cout << "\n" << std::setfill(' ') << std::setw(2) << get_value(i) << "  " :
            std::cout << std::setfill(' ') << std::setw(2) << get_value(i) << "  ";
    }
    std::cout << "\n\n";
    // #ifdef WIN32
    // system("PAUSE");
    // #endif
}

void GEMS_PICKER::delete_marked_region() {
    int j, c, gems_number = 0;
    for (int i = 0; i < r_max * c_max; i++) {
        if (T[i] == 1) {
            gems_number++;
            j = i; // if it is only one gem of given colour, remember its index (j)
            c = get_value(i); // and colour (c) - to be later restored
            T[i] = 0;
            set_value(i, 0);
        }
    }

    if (gems_number < 2) { // marked area must be greater than one!
        play_sample(sample_sound_02, 255, 127, 1000, 0);
        T[j] = 0;
        set_value(j, c);
        return;
    }
    play_sample(sample_sound_01, 255, 127, 1000, 0);
    bool flag;
    do {
        flag = false;
        rest(100); // "gravity" delay
        draw();
        for (int col = 0; col < c_max; col++) {
            for (int col_entry = 0; col_entry < r_max - 1; col_entry++) {
                int i = col + col_entry * c_max;
                if ((get_value(i + c_max) == 0) && (get_value(i) != 0)) {
                    set_value(i + c_max, get_value(i));
                    set_value(i, 0);
                    // move down one gem and set flag indicator
                    // that the operation took place and should be continued at most once more
                    flag = true;
                }
            }
        }
    } while (flag != false);

    if (GAME_MODE == 9) {
        // restore diamonds
        for (int i = 0; i < r_max * c_max; i++) {
            if (get_value(i) == 0) {
                set_value(i, 1 + rand() % GAME_MODE);
            }
        }
    }
}

void GEMS_PICKER::check_board() {
    for (int i = 0; i < r_max * c_max; i++) {
        if (get_value(i) != 0) {
            active_gem = get_value(i);
            c0(i);
            int gems_number = 0;
            for (int t = 0; t < r_max * c_max; t++) {
                if (T[t] == 1) {
                    T[t] = 0;
                    gems_number++;
                }
            }
            if (gems_number > 1) {
                return;
            }
        }
    }

    // int xx = (sx_size - BITMAP -> w) / 2;
    // int yy = (sy_size - BITMAP -> h) / 2;
    masked_blit(screen_game_02, screen, 0, 0, 0, 0, screen_game_02 -> w, screen_game_02 -> h);

    while (!key[KEY_ESC]) {
        if (key[KEY_SPACE]) {
            RESET();
            return;
        }
        if (close_button_pressed == 1) { return; }
    }
}

/*      There are at least three different methods to mark the region of adjacent tiles.
        I think the following is the most efficient 
        It resembles the movement of the butterfly from Boulder Dash:

        c0: c0 -> c1 -> c2 -> c3
        c1: c1 -> c2 -> c3 -> c0
        c2: c2 -> c3 -> c0 -> c1
        c3: c3 -> c0 -> c1 -> c2

        Exemplary execution of the sequence of cx(int) functions:

        Consider a gem of colour 1.
        Suppose player clicks on the cell indexed by 27:

        GAME_BOARD: 00 01 02 03 04 05 06 07
                    08 09 10 11 12 13 14 15
                    16 17 18 19 20 21 22 23
                    24 25 26 27 28 29 30 31
                    32 33 34 35 36 37 38 39
                    40 41 42 42 44 45 46 47
                    48 49 50 51 52 53 54 55
                    56 57 58 59 60 61 62 63

        and gems have the following configuration:

        GEMS_ARRAY: 0  0  0  0  0  0  0  0  namely, they occupy the cells:
                    0  0  0  1  0  0  0  0  11, 19, 20, 25, 26, 27, 34, 35, 36, 37, 38, 42, 44 ,45 ,46, 52, 53, 54.
                    0  0  0  1  1  0  0  0
                    0  1  1 *1  0  0  0  0  asterisk * indicates the clicked cell
                    0  0  1  1  1  1  1  0
                    0  0  1  0  1  1  1  0
                    0  0  0  0  1  1  1  0
                    0  0  0  0  0  0  0  0

        First c0(27) is executed, and it triggers a sequence of events:

        s:[] is a stack

        c0(27) s:[]
        c3(35) s:[c0]
        c2(34) s:[c0, c3]
        c1(26) s:[c0, c3, c2]
        c2(25) s:[c0, c3, c2, c1]
        c1(26) s:[c0, c3, c2]
        c2(34) s:[c0, c3]
        :
        :
        c0(27) s:[] ---> picked region is stored in T array!

        Clicking on a different cell (out of the
        set of {11, 19, 20, 25, 26, 27, 34, 35, 36, 37, 38, 42, 44, 45 ,46, 52, 53, 54})
        would result with the different sequence of cx(int)
        functions (different stack pattern as well) but with the same
        region data storage in T.

        Each x in cx() stands for 0, 1, 2 and 3 or, from another point of view, it corresponds
        to a particular angle: 0, pi/2, pi and 3pi/2 as a standard orientation on the C-plane.

        */

void GEMS_PICKER::c0(int i) {
    T[i] = 1;

    if ((i / c_max < r_max - 1) && (get_value(i + c_max) == active_gem) && (T[i + c_max] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c0);
        c3(i + c_max);
    }
    if ((i % c_max < c_max - 1) && (get_value(i + 1) == active_gem) && (T[i + 1] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c0);
        c0(i + 1);
    }
    if ((i / c_max > 0) && (get_value(i - c_max) == active_gem) && (T[i - c_max] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c0);
        c1(i - c_max);
    }
    if ((i % c_max > 0) && (get_value(i - 1) == active_gem) && (T[i - 1] != 1)) { // additional checking for initial track
        fp_stack.push_back(&GEMS_PICKER::c0);
        c2(i - 1);
    }
//  in order:
//      1. get pointer
//      2. clear stack
//      3. execute pointer == last-called cx(int) function // (this->*fp_stack.back())(i...);
    CALL_PREVIOUS_FUNCTION(i - 1);
//  if you can simplify it ==> LET ME KNOW!!
}

void GEMS_PICKER::c1(int i) {
    T[i] = 1;

    if ((i % c_max < c_max - 1) && (get_value(i + 1) == active_gem) && (T[i + 1] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c1);
        c0(i + 1);
    }
    if ((i / c_max > 0) && (get_value(i - c_max) == active_gem) && (T[i - c_max] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c1);
        c1(i - c_max);
    }
    if ((i % c_max > 0) && (get_value(i - 1) == active_gem) && (T[i - 1] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c1);
        c2(i - 1);
    }

    CALL_PREVIOUS_FUNCTION(i + c_max);
}

void GEMS_PICKER::c2(int i) {
    T[i] = 1;

    if ((i / c_max > 0) && (get_value(i - c_max) == active_gem) && (T[i - c_max] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c2);
        c1(i - c_max);
    }
    if ((i % c_max > 0) &&(get_value(i- 1) == active_gem) && (T[i - 1] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c2);
        c2(i - 1);
    }
    if ((i / c_max < r_max - 1) && (get_value(i + c_max) == active_gem) && (T[i + c_max] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c2);
        c3(i + c_max);
    }

    CALL_PREVIOUS_FUNCTION(i + 1);
}

void GEMS_PICKER::c3(int i) {
    T[i] = 1;

    if ((i % c_max > 0) && (get_value(i - 1) == active_gem) && (T[i - 1] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c3);
        c2(i - 1);
    }
    if ((i / c_max < r_max - 1) && (get_value(i + c_max) == active_gem) && (T[i + c_max] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c3);
        c3(i + c_max);
    }
    if ((i % c_max < c_max - 1) && (get_value(i + 1) == active_gem) && (T[i + 1] != 1)) {
        fp_stack.push_back(&GEMS_PICKER::c3);
        c0(i + 1);
    }

    CALL_PREVIOUS_FUNCTION(i - c_max);
}

////////////////////////////////////////////////////////////////////////////////
int main(int ac, char **av) {
    GEMS_PICKER GAME;
    GAME.toggle_mode();
    return 0;
}
END_OF_MAIN()
////////////////////////////////////////////////////////////////////////////////
