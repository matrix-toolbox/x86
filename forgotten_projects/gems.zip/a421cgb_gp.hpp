// aNNNcgb_gp.hpp : a = allegro, NNN = current version used in DevPak
//                 c = for cell
//                 g = for game
//                 b = for board... gp = for gems picker
//
// 20130402 : [z5] 142 / 5 = 28(!) LOL

#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

#include "allegro.h"

////////////////////////////////////////////////////////////////////////////////

// ALLEGRO
// turn [x]-button handling on
volatile int close_button_pressed = 0;

void close_button_handler(void) {
    close_button_pressed = 1;
}
END_OF_FUNCTION(close_button_handler)

// ALLEGRO
void ERROR_MESSAGE(char *error_msg) {
    set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
    allegro_message(error_msg);
    allegro_exit();
}

////////////////////////////////////////////////////////////////////////////////

//
// global tables of colours for tiles under "plain GFX"
//
int TCR[9] = {   0,   0, 255, 200, 200,   0, 250, 110, 120 };
int TCG[9] = {   0, 255,   0, 200,   0, 200, 250,  20, 120 };
int TCB[9] = { 255,   0,   0,   0, 200, 200, 250, 210, 120 };

////////////////////////////////////////////////////////////////////////////////

class ALLEGRO_GFX {
    bool GFX_RICH_MODE;

public:
    BITMAP * screen_buffer;
    BITMAP * screen_game_01; // welcome screen
    BITMAP * screen_game_02; // toggle mode screen

    BITMAP * tile_pointer;

    std::vector<BITMAP *> tiles_array;
    std::vector<BITMAP *> tiles_array_h; // hover tiles

    SAMPLE * sample_sound_01;
    SAMPLE * sample_sound_02;

    int get_GFX_MODE(void) { return GFX_RICH_MODE; }

    ALLEGRO_GFX();
   ~ALLEGRO_GFX();
};

ALLEGRO_GFX::ALLEGRO_GFX() {
    GFX_RICH_MODE = true;

    allegro_init();

//  enable x-button to exit the window
    LOCK_FUNCTION(close_button_handler);
    set_close_button_callback(close_button_handler);
//  allegro miscellaneous
    install_keyboard();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, sx_size, sy_size, 0, 0);
    install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, "");
    clear_to_color(screen, makecol(0, 0, 0));

    install_mouse();
    show_mouse(screen);
    unscare_mouse();

    set_window_title(GAME_WINDOW_CAPTION);

    screen_buffer = NULL;
    screen_buffer = create_bitmap(sx_size, sy_size);
    if (!screen_buffer)
        ERROR_MESSAGE("gfx error...");

    screen_game_01 = NULL;
    screen_game_01 = load_bmp("screen_game_01.bmp", default_palette);
    if (!screen_game_01)
        ERROR_MESSAGE("gfx file not found!");

    screen_game_02 = NULL;
    screen_game_02 = load_bmp("screen_game_02.bmp", default_palette);
    if (!screen_game_02)
        ERROR_MESSAGE("gfx file not found!");

    sample_sound_01 = NULL;
    sample_sound_01 = load_sample("sound_01.wav"); // sound when removing group of gems
    if (!sample_sound_01)
        ERROR_MESSAGE("sound_01.wav file not found!");

    sample_sound_02 = NULL;
    sample_sound_02 = load_sample("sound_02.wav"); // sound when picked a single gem (no possibility to be removed)
    if (!sample_sound_02)
        ERROR_MESSAGE("sound_02.wav file not found!");

    if (GFX_RICH_MODE == true) {
        std::string tile_path;
        tile_pointer = NULL;
        for (int tn = 48; tn < 48 + 9; tn++) { // load full set of gems
            tile_path = "gem_";
            tile_path += tn;
            tile_path += ".bmp";
            tile_pointer = load_bmp(tile_path.c_str(), default_palette);
            if (!tile_pointer) {
                // ERROR_MESSAGE("gfx file not found...");
                GFX_RICH_MODE = false;
                break;
                }

            tiles_array.push_back(tile_pointer);

            tile_path = "gem_";
            tile_path += tn;
            tile_path += "h.bmp"; // hover gems
            tile_pointer = load_bmp(tile_path.c_str(), default_palette);
            if (!tile_pointer) {
                // ERROR_MESSAGE("gfx file not found...");
                GFX_RICH_MODE = false;
                break;
            }
            tiles_array_h.push_back(tile_pointer);
        }
    }
}

ALLEGRO_GFX::~ALLEGRO_GFX() {
    destroy_bitmap(screen_buffer);

    destroy_bitmap(screen_game_01);
    destroy_bitmap(screen_game_02);

    if (GFX_RICH_MODE == true) {
        destroy_bitmap(tile_pointer);
    }

    destroy_sample(sample_sound_01);
    destroy_sample(sample_sound_02);

    allegro_exit();
}

class CELL {
    int cx;
    int cy;

    int background_colour;
    int status;
    int value;
    int active_cell;

public:
    static const int cell_size = _cell_size;

    void draw_cell(void);

    void set_value(int val) { value = val; }
    int  get_value(void) { return value; }

    void set_cx(int x) { cx = x; }
    void set_cy(int y) { cy = y; }
    void set_ac(int ac) { active_cell = ac; }
    int get_cx(void) { return cx; }
    int get_cy(void) { return cy; }
    int get_ac(void) { return active_cell; }

    CELL() {};
   ~CELL() {};
};

class GAME_BOARD : public CELL, public ALLEGRO_GFX {
    int r_max;
    int c_max;

    static const int cell_space = _cell_space;
    static const int x_origin = _x_origin;
    static const int y_origin = _y_origin;

    CELL * GAME_ARRAY;

public:
    void prepare(void);
    void draw(void);
    void cell_hover(int, int);

    void set_value(int cell_index, int val) { GAME_ARRAY[cell_index].set_value(val); }
    int  get_value(int cell_index) { return GAME_ARRAY[cell_index].get_value(); }
    int  get_cx(int cell_index) { return GAME_ARRAY[cell_index].get_cx(); }
    int  get_cy(int cell_index) { return GAME_ARRAY[cell_index].get_cy(); }

    GAME_BOARD();
   ~GAME_BOARD();
};

void GAME_BOARD::prepare(void) {
    for (int i = 0; i < r_max * c_max; i++) {
        GAME_ARRAY[i].set_cx(x_origin + (cell_size + cell_space) * (i % c_max));
        GAME_ARRAY[i].set_cy(y_origin + (cell_size + cell_space) * (i / c_max));
    }
}

GAME_BOARD::GAME_BOARD() {
    r_max = 9; // fixed defaults
    c_max = 12;
    GAME_ARRAY = new CELL[r_max * c_max];
    prepare();
}

GAME_BOARD::~GAME_BOARD() {
    delete[] GAME_ARRAY;
}

void GAME_BOARD::draw() {
    for (int i = 0; i < r_max * c_max; i++) {
        int t = get_value(i) - 1;
        if (t >= 0) {
            if (get_GFX_MODE() == true) {
                blit(
                    tiles_array[t],
                    screen_buffer,
                    0,
                    0,
                    get_cx(i),
                    get_cy(i),
                    tiles_array[t] -> w,
                    tiles_array[t] -> h);
            } else { // plain GFX
                circlefill(
                    screen_buffer,
                    get_cx(i) + cell_size / 2,
                    get_cy(i) + cell_size / 2,
                    cell_size / 3,
                    makecol(TCR[t], TCG[t], TCB[t]));
            }
        } else { // clear cell
            rectfill(
                screen_buffer,
                get_cx(i),
                get_cy(i),
                get_cx(i) + cell_size,
                get_cy(i) + cell_size,
                makecol(0,0,0));
        }
    }
    blit(screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
}

// highlight the cells (and the tiles) that the mouse is hovering over
void GAME_BOARD::cell_hover(int mx, int my) {
    for (int cell_index = 0; cell_index < r_max * c_max; cell_index++) {
    // if mouse is found within borders of the particular cell, the gem that is there is being highlighted
        if ((get_cx(cell_index) < mx) && (mx < get_cx(cell_index) + cell_size) &&
            (get_cy(cell_index) < my) && (my < get_cy(cell_index) + cell_size)) {
            int t = get_value(cell_index) - 1;
            if (t >= 0) {
                if (get_GFX_MODE() == true) {
                    blit(
                        tiles_array_h[t],
                        screen_buffer,
                        0,
                        0,
                        get_cx(cell_index),
                        get_cy(cell_index),
                        tiles_array_h[t] -> w,
                        tiles_array_h[t] -> h);
                } else { // plain GFX [highlighting not implemented yet]
                    circlefill(
                        screen_buffer,
                        get_cx(cell_index) + cell_size / 2,
                        get_cy(cell_index) + cell_size / 2,
                        cell_size / 2,
                        makecol(TCR[t], TCG[t], TCB[t]));
                }
            }
        } else { // otherwise cell backgound comes back to its original colour
            int t = get_value(cell_index) - 1;
            if (t >= 0) {
                if (get_GFX_MODE() == true) {
                    blit(
                        tiles_array[t],
                        screen_buffer,
                        0,
                        0,
                        get_cx(cell_index),
                        get_cy(cell_index),
                        tiles_array[t] -> w,
                        tiles_array[t] -> h);
                } else { // plain GFX [highlighting not implemented yet]
                    rectfill(
                        screen_buffer,
                        get_cx(cell_index),
                        get_cy(cell_index),
                        get_cx(cell_index) + cell_size,
                        get_cy(cell_index) + cell_size,
                        makecol(0, 0, 0));
                    circlefill(
                        screen_buffer,
                        get_cx(cell_index) + cell_size / 2,
                        get_cy(cell_index) + cell_size / 2,
                        cell_size / 3,
                        makecol(TCR[t], TCG[t], TCB[t]));
                }
            }
        }
    }
}
////////////////////////////////////////////////////////////////////////////////
