package chaos.huarong_dao.exceptions;

@Deprecated
public class DuplicateBlockCompositionException extends Exception {

    // Each block consists of a number of unit sub-blocks.
    //
    // For example a block b01_03 is made out of three sub-blocks,
    // each of which occupies one cell in the Board.boardConfiguration array by means of the Point():
    //
    //   +--+--+
    //   |  |  |
    //   +--+--+
    //   |  |
    //   +--+
    //
    // Exemplary declarations for b01_03 should read:
    //   new Block(board, new Point(0, 0), new Point(0, 1), new Point(0, 1))
    //
    // However, by accident, some sub-block may appear twice like:
    //   new Block(board, new Point(0, 0), new Point(0, 1), new Point(0, 0))
    //
    // The following Exception prevents such situations.

    public DuplicateBlockCompositionException(String string) {
        super(string);
    }

}
