package chaos.huarong_dao.solver;

import org.apache.log4j.Logger;
import chaos.huarong_dao.block.Block;
import chaos.huarong_dao.board.Board;
import chaos.huarong_dao.tools.Tools;

import java.awt.*;
import java.util.*;

/*
 *
 * Wojciech Bruzda
 *
 * Feel free to use it and fix it. :)
 *
 * 20150819 - fully working engine
 * 20150820 - minor changes
 *
 *
 */

public class HRDSolver {

    private final static Logger LOG = Logger.getLogger(HRDSolver.class);

    public static void main(String... arguments) {

//        Board board = new Board(3, 4, new Block(), new Block(), new Block(), new Block());
//
//        board.getBlock(1).setBlockComponents(new Point(0, 0), new Point(0, 1), new Point(1, 0), new Point(1, 1));
//        board.getBlock(2).setBlockComponents(new Point(2, 0));
//        board.getBlock(3).setBlockComponents(new Point(2, 1));
//        board.getBlock(4).setBlockComponents(new Point(0, 2), new Point(0, 3));
//
//        board.setWarLordTarget(new Point(1, 2), new Point(1, 3), new Point(2, 2), new Point(2, 3));
//        final int warLordBlockNumber = 1;
//
//        LOG.info(board); // initial board configuration


//      Classic Huarong Dao
        Board board = new Board(4, 5,
                new Block(), new Block(), new Block(), new Block(), new Block(),
                new Block(), new Block(), new Block(), new Block(), new Block());

        board.getBlock(1).setBlockComponents(new Point(0, 0), new Point(0, 1));
        board.getBlock(2).setBlockComponents(new Point(1, 0), new Point(2, 0), new Point(1, 1), new Point(2, 1));
        board.getBlock(3).setBlockComponents(new Point(3, 0), new Point(3, 1));
        board.getBlock(4).setBlockComponents(new Point(0, 2), new Point(0, 3));
        board.getBlock(5).setBlockComponents(new Point(3, 2), new Point(3, 3));
        board.getBlock(6).setBlockComponents(new Point(1, 2), new Point(2, 2));
        board.getBlock(7).setBlockComponents(new Point(1, 3));
        board.getBlock(8).setBlockComponents(new Point(2, 3));
        board.getBlock(9).setBlockComponents(new Point(0, 4));
        board.getBlock(10).setBlockComponents(new Point(3, 4));

        board.setWarLordTarget(new Point(1, 3), new Point(1, 4), new Point(2, 3), new Point(2, 4));
        final int warLordBlockNumber = 2;

        LOG.info(board); // initial board configuration

        // initialize all structures:
        ArrayList<ArrayList<Block>> boardConfigurationList = new ArrayList<>();

        Map<String, String> boardFingerprintMap = new HashMap<>();

        boardFingerprintMap.put(board.getBoardFingerprint(), null); // null since initial boardConf. has no ancestor
        boardConfigurationList.add(board.getBoardConfiguration());

        // SCHEME - ITERATIVE = NOT RECURSIVE!
        //
        // 1. for each block of current boardConfiguration get its directions
        // 2. move the block in [each] direction
        // 3. save the boardConfiguration if the board fingerprint is unique
        // 4. goto 1.

        ArrayList<Integer> warLordPosition = new ArrayList<>();

        ArrayList<Integer> warLordTarget = new ArrayList<>();
        for (Point point : board.getWarLordTarget()) {
            warLordTarget.add((int) point.getX());
            warLordTarget.add((int) point.getY());
        }
        Collections.sort(warLordTarget);

        int configurationOffset = 0;

        boolean warLordAtTheTarget;

        main_loop: // TODO: This doesn't seem to be so nice...
        do {
            ArrayList<Block> currentBlockConfiguration = boardConfigurationList.get(configurationOffset);

            // restore board configuration
            for (Block block : currentBlockConfiguration) {
                Set<Point> blockComponents = block.getBlockComponents();
                board.getBlock(block.getBlockNumber()).resetBlockComponents();
                for (Point component : blockComponents) {
                    board.getBlock(block.getBlockNumber()).setBlockComponents(component);
                }
            }

            String previousBoardFingerprint = board.getBoardFingerprint();

            for (int blockNumber = 1; blockNumber <= Tools.maxBlockNumber; blockNumber++) {
                // TODO: Why not: "for (Block block : board.getAllBlocks()) { ... }"?
                // TODO: Board class must be reorganised somehow...
                for (Tools.DIRECTION direction : board.getBlockDirections(blockNumber)) {
                    // move block
                    board.getBlock(blockNumber).moveBlock(direction);
                    // check if the WarLord got its position
                    warLordPosition.clear();
                    for (Point point : board.getBlock(warLordBlockNumber).getBlockComponents()) {
                        warLordPosition.add((int) point.getX());
                        warLordPosition.add((int) point.getY());
                    }
                    Collections.sort(warLordPosition);
                    warLordAtTheTarget = true;
                    for (int i = 0; i < warLordPosition.size(); i++) {
                        if (!Objects.equals(warLordPosition.get(i), warLordTarget.get(i))) {
                            warLordAtTheTarget = false;
                            break;
                        }
                    }

                    if (!boardFingerprintMap.containsKey(board.getBoardFingerprint())) { // *
                        boardFingerprintMap.put(board.getBoardFingerprint(), previousBoardFingerprint);
                        // boardFingerprintMap = { key=currentboardFingerprint, value=previousBoardFingerprint }
                        // Obviously, the first values read: { "initialBoardFingerprint", null }.
                        // When solution is found then it'll be easy to trace back all steps to the "first board".
                        boardConfigurationList.add(board.getBoardConfiguration()); // save board if its FP is unique: *
                    }

                    if (warLordAtTheTarget) { // let the [last] board configuration be saved before we stop the loop
                        break main_loop;
                    }
                    // Once the block is moved, move it back to its original position,
                    // so that other blocks in this turn (providing they are movable) can be moved
                    // without interfering current board configuration.
                    switch (direction) {
                        case SOUTH:
                            board.getBlock(blockNumber).moveBlock(Tools.DIRECTION.NORTH);
                            break;
                        case NORTH:
                            board.getBlock(blockNumber).moveBlock(Tools.DIRECTION.SOUTH);
                            break;
                        case WEST:
                            board.getBlock(blockNumber).moveBlock(Tools.DIRECTION.EAST);
                            break;
                        case EAST:
                            board.getBlock(blockNumber).moveBlock(Tools.DIRECTION.WEST);
                            break;
                    }
                }
            }

            configurationOffset++; // This is explained graphically elsewhere...

        } while (true);

        ArrayList<String> reverseHistory = new ArrayList<>();

        // restore the chain: "key-value-key-value-...-key-null" from the boardFingerprintMap
        String nextKey = board.getBoardFingerprint(); // 1st nextKey = last boardFB - a seed for the loop
        while (nextKey != null) {
            reverseHistory.add(nextKey);
            nextKey = boardFingerprintMap.get(nextKey);
        }

        Collections.reverse(reverseHistory);
        for (String boardFingerprint : reverseHistory) {
            LOG.info(board.bF2Board(boardFingerprint));
        }

        LOG.info("moves: " + reverseHistory.size());
//      NOTE: Some might count several moves of a given block as a single move.
//            Here, for example, when a unit block [1] (see below) moves two places
//            right it counts as TWO moves not ONE!
//
//            +---+---+---+---+            +---+---+---+---+            +---+---+---+---+
//            | 2 | 4   4 | 2 |            | 2 | 4   4 | 2 |            | 2 | 4   4 | 2 |
//            +   +       +   +            +   +       +   +            +   +       +   +
//            | 2 | 4   4 | 2 |            | 2 | 4   4 | 2 |            | 2 | 4   4 | 2 |
//            +---+---+---+---+            +---+---+---+---+            +---+---+---+---+
//            | 2 | 2   2 | 2 |            | 2 | 2   2 | 2 |            | 2 | 2   2 | 2 |
//            +   +---+---+   +            +   +---+---+   +            +   +---+---+   +
//            | 2 | 1 | 1 | 2 |            | 2 | 1 | 1 | 2 |            | 2 | 1 | 1 | 2 |
//            +---+---+---+---+  1st move  +---+---+---+---+  2nd move  +---+---+---+---+
//            |[1]|       | 1 | --------->     |[1]|   | 1 | --------->         |[1]| 1 |
//            +---+_______+---+            +---+___+---+                     ___+---+---+
//                 ^^^^^^^                      ^^^^^^^                      ^^^^^^^
//                                                                +---+---+
//            Thus, for the classic Huarong Dao puzzle            | 4   4 |
//            there can be 81 moves to set the WarLord (Cao Cao): +       + free, or
//                                                                | 4   4 |
//                                                                +---+---+
//
//            in the case of the above algorithm there are 119 moves!
//            All depends on the counting method...

    }

}
