package chaos.huarong_dao.tools;

public class Tools {

    private static int nextBlockNumber;

    public static int maxBlockNumber;

    public static int getNextBlockNumber() {
        return ++nextBlockNumber;
    }

    public enum DIRECTION {
        NORTH, WEST, SOUTH, EAST
    }
}

