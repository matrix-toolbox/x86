package chaos.huarong_dao.block;

import chaos.huarong_dao.tools.Tools;

import java.awt.*;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Block {

    private Set<Point> blockComponents = new HashSet<>();
    private int blockNumber;

    public Set<Point> getBlockComponents() {
        return blockComponents;
    }

    public void resetBlockComponents() {
        blockComponents.clear();
    }

    public void setBlockComponents(Point point) {
        blockComponents.add(point);
    }

    public void setBlockComponents(Point... components) {
        resetBlockComponents();
        Collections.addAll(blockComponents, components);
    }

    public int getBlockNumber() {
        return blockNumber;
    }

    public void setBlockNumber(int blockNumber) {
        this.blockNumber = blockNumber;
    }

    public Block() {
        blockNumber = Tools.getNextBlockNumber();
        Tools.maxBlockNumber = blockNumber;
    }

    @SuppressWarnings("unused")
    public Block(Point... points) {
        blockNumber = Tools.getNextBlockNumber();
        Tools.maxBlockNumber = blockNumber;

        Collections.addAll(blockComponents, points);
    }

    public void moveBlock(Tools.DIRECTION direction) {
        Set<Point> movedComponents = new HashSet<>();

        for (Point component : blockComponents) {
            int x = (int) component.getX();
            int y = (int) component.getY();

            switch(direction) {
                case SOUTH:
                    movedComponents.add(new Point(x, y + 1));
                    break;
                case NORTH:
                    movedComponents.add(new Point(x, y - 1));
                    break;
                case EAST:
                    movedComponents.add(new Point(x + 1, y));
                    break;
                case WEST:
                    movedComponents.add(new Point(x - 1, y));
                    break;
            }
        }
        blockComponents.clear();
        blockComponents.addAll(movedComponents);
    }

    @Override
    public String toString() {
        String blockNumberString = blockNumber + "";
        if (blockNumber < 10) {
            blockNumberString = "0" + blockNumber;
        }
        // comma-separated human-readable representation of a block instance
        StringBuilder blockInformation = new StringBuilder("block number: " + blockNumberString
                + ", block component location: ");
        String delimiter = "";
        for (Point component : this.blockComponents) {
            blockInformation.append(delimiter)
                    .append("[")
                    .append((int) component.getX())
                    .append(", ")
                    .append((int) component.getY())
                    .append("]");
            delimiter = ", ";
        }
        return blockInformation.toString();
    }

}