package chaos.huarong_dao.board;

import chaos.huarong_dao.block.Block;
import chaos.huarong_dao.tools.Tools;

import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Set;

// Board is a rectangular array with boardWidth columns and boardHeight rows,
// Board holds the coordinates of the destination place for the WarLord - the specified
// block which is to be unlocked from the other blocks.
// Board also serves the logic to check if the formerly initialized blocks
// do not collide when moving: isBlockMovable();
public class Board {

    private ArrayList<Block> blockList;

    public Block getBlock(int blockNumber) {
        for (Block block : blockList) {
            if (block.getBlockNumber() == blockNumber) {
                return block;
            }
        }
        return null; // TODO: Replace it with a proper Exception!
    }

    private ArrayList<Point> WarLordTarget;
    private int boardWidth;
    private int boardHeight;

    public void setWarLordTarget(Point... points) {
        WarLordTarget = new ArrayList<>();
        Collections.addAll(WarLordTarget, points);
    }

    public ArrayList<Point> getWarLordTarget() {
        return WarLordTarget;
    }

    public Board(int boardWidth, int boardHeight, Block... blocks) {
        this.boardWidth = boardWidth;
        this.boardHeight = boardHeight;

        blockList = new ArrayList<>();
        Collections.addAll(blockList, blocks);
    }

    public String getBoardFingerprint() {
        int[][] boardFingerprint = new int[boardWidth][boardHeight];
        for (Block block : blockList) {
            for (Point point : block.getBlockComponents()) {
                boardFingerprint[(int) point.getX()][(int) point.getY()] =
                        block.getBlockComponents().size();
            }
        }
        String flatBoardFingerprint = "";
        for (int y = 0; y < boardHeight; y++) {
            for (int x = 0; x < boardWidth; x++) {
                flatBoardFingerprint += boardFingerprint[x][y];
            }
        }
        return flatBoardFingerprint;
    }

    public boolean isBlockMovable(int blockNumber, Tools.DIRECTION direction) {

        Set<Point> blockComponents = getBlock(blockNumber).getBlockComponents();

        for (Point point : blockComponents) {
            int x = (int) point.getX();
            int y = (int) point.getY();
            switch (direction) {
                case NORTH:
                    // check, if it is possible to move it at all - similar for other directions...
                    if (y == 0) {
                        return false;
                    }
                    // check, if there is an empty space - no collision with other blocks
                    for (Block block : blockList) {
                        if (block.getBlockNumber() != blockNumber) {
                            Set<Point> otherBlockComponents = block.getBlockComponents();
                            for (Point p : otherBlockComponents) {
                                if (p.getX() == x && p.getY() == y - 1) { // TODO: double vs. int?
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case SOUTH:
                    if (y + 1 == boardHeight) {
                        return false;
                    }
                    for (Block block : blockList) {
                        if (block.getBlockNumber() != blockNumber) {
                            Set<Point> otherBlockComponents = block.getBlockComponents();
                            for (Point p : otherBlockComponents) {
                                if (p.getX() == x && p.getY() == y + 1) {
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case EAST:
                    if (x + 1 == boardWidth) {
                        return false;
                    }
                    for (Block block : blockList) {
                        if (block.getBlockNumber() != blockNumber) {
                            Set<Point> otherBlockComponents = block.getBlockComponents();
                            for (Point p : otherBlockComponents) {
                                if (p.getX() == x + 1 && p.getY() == y) {
                                    return false;
                                }
                            }
                        }
                    }
                    break;
                case WEST:
                    if (x == 0) {
                        return false;
                    }
                    for (Block block : blockList) {
                        if (block.getBlockNumber() != blockNumber) {
                            Set<Point> otherBlockComponents = block.getBlockComponents();
                            for (Point p : otherBlockComponents) {
                                if (p.getX() == x - 1 && p.getY() == y) {
                                    return false;
                                }
                            }
                        }
                    }
                    break;
            }
        }
        return true;
    }

    public ArrayList<Block> getBoardConfiguration() {

        ArrayList<Block> currentBlockConfiguration = new ArrayList<>();

        final int mbn = Tools.maxBlockNumber;

        for (Block block : blockList) {
            Block newBlock = new Block(); // creates a new unwanted blockNumber...

            Set<Point> blockComponents = block.getBlockComponents();
            for (Point component : blockComponents) {
                newBlock.setBlockComponents(component);
            }
            newBlock.setBlockNumber(block.getBlockNumber()); // ...so [static numbers] must be reloaded!
            currentBlockConfiguration.add(newBlock);
        }

        Tools.maxBlockNumber = mbn; // preserve maxBlockNumber

        // all the tricks above guarantee that we save a copy of the board not the current block references!
        // TODO: Simplify it!
        return currentBlockConfiguration;
    }

    @Override
    public String toString() {
        String boardInformation = "";

        int[][] boardArray = new int[boardWidth][boardHeight];

        for (Block block : blockList) {
            for (Point point : block.getBlockComponents()) {
                boardArray[(int) point.getX()][(int) point.getY()] = block.getBlockNumber();
            }
        }

        for (int y = 0; y < boardHeight; y++) {
            boardInformation += "\n";
            for (int x = 0; x < boardWidth; x++) {
                if (boardArray[x][y] < 10) {
                    boardInformation += "0"; // number formatting with leading zeroes
                }
                boardInformation += boardArray[x][y] + " ";
            }
        }
        // TODO: "*" instead of the warLord numbers...
        return boardInformation;
    }

    public String bF2Board(String boardFingerprint) {
        String boardInformation = "";

        for (int i = 0; i < boardFingerprint.length(); i++) {
            if (i % boardWidth == 0) {
                boardInformation += "\n";
            }
            boardInformation += "0" + boardFingerprint.charAt(i) + " "; // TODO: Problem with #{components} > 9
        }

        return boardInformation;
    }

    public ArrayList<Tools.DIRECTION> getBlockDirections(int blockNumber) {
        ArrayList<Tools.DIRECTION> directionArray = new ArrayList<>();

        for (Tools.DIRECTION direction : Tools.DIRECTION.values()) {
            if (isBlockMovable(blockNumber, direction)) {
                directionArray.add(direction);
            }
        }
        return directionArray;
    }

}
