package chaos.huarong_dao.exceptions;

@Deprecated
public class BlockCollisionException extends Exception {

    public BlockCollisionException(String string) {
        super(string);
    }

}
