#include <iostream>
#include <iomanip>
#include <vector>
#include <string>

#include "allegro.h"

////////////////////////////////////////////////////////////////////////////////

//      wojciech bruzda

//      ALLEGRO
//      turn [x]-button handling on
        volatile int close_button_pressed = 0;

        void close_button_handler(void)
                {
                close_button_pressed = 1;
                }
        END_OF_FUNCTION(close_button_handler)


//      ALLEGRO
        void ERROR_MESSAGE(char *error_message)
                {
                set_gfx_mode(GFX_TEXT, 0, 0, 0, 0);
                allegro_message(error_message);
                allegro_exit();
                }

////////////////////////////////////////////////////////////////////////////////

//
// global tables of colours for tiles under "plain gfx"
//
int TCR[9] = {   0,   0, 255, 200, 200,   0, 250, 110, 120 };
int TCG[9] = {   0, 255,   0, 200,   0, 200, 250,  20, 120 };
int TCB[9] = { 255,   0,   0,   0, 200, 200, 250, 210, 120 };

////////////////////////////////////////////////////////////////////////////////

class ALLEGRO_GFX
        {
        bool GFX_RICH_MODE;

public: BITMAP * screen_buffer;
        BITMAP * screen_game_01; // welcome screen
        BITMAP * screen_game_02; // toggle mode screen

        BITMAP * tile_ptr;

        std::vector<BITMAP *> tiles_array;
        std::vector<BITMAP *> tiles_array_h; // hover tiles

        SAMPLE * sample_sound_01;
        SAMPLE * sample_sound_02;

        int get_GFX_MODE(void) { return GFX_RICH_MODE; }

        ALLEGRO_GFX();
       ~ALLEGRO_GFX();
        };

ALLEGRO_GFX::ALLEGRO_GFX()
        {
        GFX_RICH_MODE = true;

        allegro_init();

//      enable x-button to exit the window
        LOCK_FUNCTION(close_button_handler);
        set_close_button_callback(close_button_handler);

//      allegro miscellaneous
        install_keyboard();
        set_color_depth(16);
        set_gfx_mode(GFX_AUTODETECT_WINDOWED, sx_size, sy_size, 0, 0);
        install_sound(DIGI_AUTODETECT, MIDI_AUTODETECT, "");
        clear_to_color(screen, makecol(0, 111, 0));

        install_mouse();
        show_mouse(screen);
        unscare_mouse();

        set_window_title(GAME_WINDOW_CAPTION);

        screen_buffer = NULL;
        screen_buffer = create_bitmap(sx_size, sy_size);
        if (!screen_buffer)
//              ERROR_MESSAGE("gfx error...");
                GFX_RICH_MODE = false;

        screen_game_01 = NULL;
        screen_game_01 = load_bmp("screen_game_01.bmp", default_palette);
        if (!screen_game_01)
//              ERROR_MESSAGE("gfx file not found!");
                GFX_RICH_MODE = false;

        screen_game_02 = NULL;
        screen_game_02 = load_bmp("screen_game_02.bmp", default_palette);
        if (!screen_game_02)
//              ERROR_MESSAGE("gfx file not found!");
                GFX_RICH_MODE = false;

        sample_sound_01 = NULL;
        sample_sound_01 = load_sample("sound_01.wav"); // sound when removing group of gems
        if (!sample_sound_01)
                ERROR_MESSAGE("sound_01.wav file not found!");

        sample_sound_02 = NULL;
        sample_sound_02 = load_sample("sound_02.wav"); // sound when picked a single gem (no possibility to be removed)
        if (!sample_sound_02)
                ERROR_MESSAGE("sound_02.wav file not found!");

        if (GFX_RICH_MODE == true) {
                std::string tile_path;
                tile_ptr=NULL;

                for (int tn = 48; tn < 48 + 9; tn++) { // load full set of gems
                        tile_path = "gem_";
                        tile_path += tn;
                        tile_path += ".bmp";
                        tile_ptr = load_bmp(tile_path.c_str(), default_palette);
                        if (!tile_ptr) {
//                              ERROR_MESSAGE("gfx file not found...");
                                GFX_RICH_MODE = false;
                                break;
                        }

                        tiles_array.push_back(tile_ptr);

                        tile_path = "gem_";
                        tile_path += tn;
                        tile_path += "h.bmp"; // hover gems
                        tile_ptr = load_bmp(tile_path.c_str(), default_palette);
                        if (!tile_ptr) {
//                              ERROR_MESSAGE("gfx file not found...");
                                GFX_RICH_MODE = false;
                                break;
                        }

                        tiles_array_h.push_back(tile_ptr);
                }
        }
}

ALLEGRO_GFX::~ALLEGRO_GFX() {
        destroy_bitmap(screen_buffer);

        destroy_bitmap(screen_game_01);
        destroy_bitmap(screen_game_02);

        if (GFX_RICH_MODE == true) {
                destroy_bitmap(tile_ptr);
        }

        destroy_sample(sample_sound_01);
        destroy_sample(sample_sound_02);

        allegro_exit();
}

class CELL {
        int cx;
        int cy;

        int background_colour;
        int status;
        int value;
        int active_cell;


public: static const int cell_size = _cell_size;

        void draw_cell(void);

        void set_value(int val) { value = val; }
        int  get_value(void) { return value; }

        void set_cx(int x) { cx = x; }
        void set_cy(int y) { cy = y; }
        void set_ac(int ac) { active_cell = ac; }
        int  get_cx(void) { return cx; }
        int  get_cy(void) { return cy; }
        int  get_ac(void) { return active_cell; }

        CELL() {};
       ~CELL() {};
};

class GAME_BOARD : public CELL, public ALLEGRO_GFX {
        int r_max;
        int c_max;

        static const int cell_space = _cell_space;
        static const int x_origin = _x_origin;
        static const int y_origin = _y_origin;

        CELL * GAME_ARRAY;

public: void prepare(void);
        void draw(void);
        void cell_hover(int, int);

        void set_value(int cell_index, int val) { GAME_ARRAY[cell_index].set_value(val); }
        int  get_value(int cell_index) { return GAME_ARRAY[cell_index].get_value(); }
        int  get_cx(int cell_index) { return GAME_ARRAY[cell_index].get_cx(); }
        int  get_cy(int cell_index) { return GAME_ARRAY[cell_index].get_cy(); }

        GAME_BOARD();
       ~GAME_BOARD();
};

void GAME_BOARD::prepare(void) {
        for (int i = 0; i < r_max * c_max; i++) {
                GAME_ARRAY[i].set_cx(x_origin + (cell_size + cell_space) * (i % c_max));
                GAME_ARRAY[i].set_cy(y_origin + (cell_size + cell_space) * (i / c_max));
        }
}

GAME_BOARD::GAME_BOARD() {
        r_max = 8; // fixed defaults
        c_max = 8;
        GAME_ARRAY = new CELL[r_max * c_max];
        prepare();
}

GAME_BOARD::~GAME_BOARD() {
        delete[] GAME_ARRAY;
}

void GAME_BOARD::draw() {
        for (int i = 0; i < r_max * c_max; i++) {
                int t = get_value(i) - 1;
                if (t >= 0) {
                        if (get_GFX_MODE() == true) {
//                              blit(
//                                  gems_array[mc],
//                                  screen_buffer,
//                                  0,
//                                  0,
//                                  cell[cell_index].cx,
//                                  cell[cell_index].cy,
//                                  gems_array[mc] -> w,
//                                  gems_array[mc] -> h);
                        }
                        else { // plain GFX
                                circlefill(
                                    screen_buffer,
                                    get_cx(i) + cell_size / 2,
                                    get_cy(i) + cell_size / 2,
                                    cell_size / 3,
                                    makecol(TCR[t], TCG[t], TCB[t]));
                        }
                }
                else { // clear cell
                        rectfill(
                            screen_buffer,
                            get_cx(i),
                            get_cy(i),
                            get_cx(i) + cell_size,
                            get_cy(i) + cell_size,
                            makecol(110, 0, 0));
                }
        }
        blit(screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
}

// highlight the cells (and the tiles) that the mouse is hovering over
//
//
void GAME_BOARD::cell_hover(int mx, int my) {
        for (int cell_index = 0; cell_index < r_max * c_max; cell_index++) {
                if ((get_cx(cell_index) < mx) && (mx < get_cx(cell_index) + cell_size) &&
                    (get_cy(cell_index) < my) && (my < get_cy(cell_index) + cell_size)) {
                        int t = get_value(cell_index) - 1;
                        if (t >= 0) {
                                if (get_GFX_MODE() == true) {
//                                        blit(
//                                            gems_array_h[mc],
//                                            screen_buffer,
//                                            0,
//                                            0,
//                                            cell[cell_index].cx,
//                                            cell[cell_index].cy,
//                                            gems_array_h[mc] -> w,
//                                            gems_array_h[mc] -> h);
                                }
                                else { // plain GFX [highlighting not implemented yet]
                                        circlefill(
                                            screen_buffer,
                                            get_cx(cell_index) + cell_size / 2,
                                            get_cy(cell_index) + cell_size / 2,
                                            cell_size / 2,
                                            makecol(TCR[t], TCG[t], TCB[t]));
                                }
                        }
                }
                else { // otherwise cell backgound comes back to its original colour
                        int t = get_value(cell_index) - 1;
                        if (t >= 0) {
                                if (get_GFX_MODE() == true) {
//                                        blit(
//                                            gems_array[mc],
//                                            screen_buffer,
//                                            0,
//                                            0,
//                                            cell[cell_index].cx,
//                                            cell[cell_index].cy,
//                                            gems_array[mc] -> w,
//                                            gems_array[mc] -> h);
                                }
                                else { // plain GFX [highlighting not implemented yet]
                                        rectfill(
                                            screen_buffer,
                                            get_cx(cell_index),
                                            get_cy(cell_index),
                                            get_cx(cell_index) + cell_size,
                                            get_cy(cell_index) + cell_size,
                                            makecol(0,0,0));
                                        circlefill(
                                            screen_buffer,
                                            get_cx(cell_index) + cell_size / 2,
                                            get_cy(cell_index) + cell_size / 2,
                                            cell_size / 3,
                                            makecol(TCR[t], TCG[t], TCB[t]));
                                }
                        }
                }
        }
}

//
// game specifications
//
#define _cell_size 60;
#define _cell_space 2;
#define _x_origin 22;
#define _y_origin 22;

const char * GAME_WINDOW_CAPTION = "BOARD_GAME_TEMPLATE | v20130402 | wojciech bruzda";

const int sx_size = 900; // screen size for ALLEGRO
const int sy_size = 700;

////////////////////////////////////////////////////////////////////////////////

#include "a421cgb.hpp"

class THE_GAME: public GAME_BOARD {
        int r_max;
        int c_max;

public: void init(void);
        void play(void);

        THE_GAME();
        THE_GAME(int, int);
       ~THE_GAME() {} ;
};

void THE_GAME::init() {
        for (int i = 0; i < r_max * c_max; i++) {
                set_value(i, rand() % 10);
        }
}

THE_GAME::THE_GAME() : GAME_BOARD() {
        r_max = 8; // set default values
        c_max = 8;
}

THE_GAME::THE_GAME(int rm, int cm) : GAME_BOARD(rm, cm) {
        r_max = rm;
        c_max = cm;
}

void THE_GAME::play() {
        init();

        int allegro_mx = 0, allegro_my = 0, allegro_mb = 0; // allegro: mouse [x], [y] and its [b]utton

        clear_to_color(screen_buffer, makecol(0, 0, 0));

        while (!key[KEY_ESC]) {
//              if (key[KEY_SPACE]) { RESET(); }
                if (close_button_pressed == 1) { break; }

                if (allegro_mx != mouse_x || allegro_my != mouse_y || allegro_mb != mouse_b) {
                        allegro_mx = mouse_x;
                        allegro_my = mouse_y;
                        allegro_mb = mouse_b;
                }

                cell_hover(allegro_mx, allegro_my);
                draw();

                if (allegro_mb == 1) {
                        while (allegro_mb == mouse_b) {} // prevent dragging mouse when mouse button is down

                        for (int cell_index = 0; cell_index<r_max*c_max; cell_index++) {
                                if ((get_cx(cell_index) < allegro_mx) && (allegro_mx < get_cx(cell_index) + cell_size) &&
                                    (get_cy(cell_index) < allegro_my) && (allegro_my < get_cy(cell_index) + cell_size)) {
                                        set_ac(cell_index);
                                        // THE_GAME'S BODY...
                                    }
                        }
                        clear_keybuf();
                }
                blit(screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
        }

        clear_to_color(screen_buffer, makecol(0, 0, 0));
}

////////////////////////////////////////////////////////////////////////////////

int main(int ac, char** av) {
    THE_GAME GAME(7, 11);
    GAME.play();
    return 0;
}
END_OF_MAIN()

////////////////////////////////////////////////////////////////////////////////
