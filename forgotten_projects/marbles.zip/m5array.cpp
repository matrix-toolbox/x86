/*
=========================================
m5array path simulation * wojciech bruzda
=========================================

20130226 : [0012]
20130227 : [00x2] amoeba
20130228 : [00x2] allegro.h --> m5array_a.cpp

PROBLEM DESCRIPTION
===================
Spread m_max marbles (any non-zero elements) on the m5array[r_max][c_max].
It is just the technical assumption that
last marble (index = m_max) is erased and plays the role of an empty
cell - a destination place [f] while the second-to-last
one (index = m_max - 1) is the choosen one - an origin [i].

	[i] = [ir, ic] : coordinates of the origin
	
	[f] = [fr, fc] : coordinates of the destination

Exemplary initial deployment (without marbles):

m5_array[][] = [ . . . . . . . . ] where (dot) . = entry of the array
               [ . i . . . . . . ] . = 0 == empty cell
               [ . . . . . . . . ] . = k == marble number for k = 1 .. 9
               [ . . . . . . . . ]
               [ . . . . . . f . ]
               [ . . . . . . . . ]
               [ . . . . . . . . ]
               [ . . . . . . . . ]

The question is, can the chosen marble go form [i] to [f]
obeying the rock-chess rule movements, for example:

m5_array[][] = [ . . . . . . . . ] where (dot) . = entry of the array
               [ . i G G . . . . ] and G marks an exemplary path
               [ . . . G . . . . ]
               [ . . . G . . . . ]
               [ . . . G . . f . ]
               [ . . . G . . G . ]
               [ . . . G G G G . ]
               [ . . . . . . . . ]

If there are no obstacles on the way, the path appears on the board and
the appropriate cells turn green. In other case, if it is impossible to
connect the marked points, they turn red.

	Path preparation
	----------------
	The path can go only horizontally or
        vertically - diagonal direction is excluded. An additional
        path_array[][] table is prepared with ONE at
        the origin: path_array[ir][ic] = 1.
	
	Let present_step = 1.
	
	In each step of the loop the empty cells adjacent to the ones
        with value = present_step are given the
        value = present_step + 1 [amoeba development]:
	
	path_array[r][c] = present_step =>
		{
//              provided that path_array[r+-...][c+-...] is valid...

		path_array[r-1][c] = present_step + 1
		path_array[r][c+1] = present_step + 1
		path_array[r+1][c] = present_step + 1
		path_array[r][c-1] = present_step + 1
		}

	The loop goes either until it reaches the cell indexed
        by [fr, fc] or it is impossible to increase the value of the
        present_step. In the latter case the path cannot be constructed
	and the procedure fails.

	Anyway, if the destination [f] is reachable, another loop
        starts at [f] and goes to [i] tracing the descending numbers from
        the last value of the present_step down to 2 - the origin itself.
        The cells that the loop goes through are marked "green" and
	the path is being established.

		EXAMPLE:

		m5array:
		[ 1 ] [ - ] [ - ] [ F ] [ - ] [ 3 ]
		[ 2 ] [ 3 ] [ 2 ] [ - ] [ - ] [ 4 ]
		[ I ] [ - ] [ - ] [ 3 ] [ - ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]
		[ - ] [ - ] [ 3 ] [ 4 ] [ 1 ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ 3 ]
		[ - ] [ - ] [ 2 ] [ - ] [ - ] [ 7 ]

		path_array: [G = -1]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ] ----> [ - ] [ - ] [ - ] [ F ] [ 9 ] [ - ] ----> [ - ] [ - ] [ - ] [ G ] [ G ] [ - ] 
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ - ] [ - ] [ - ] [ 9 ] [ 8 ] [ - ]       [ - ] [ - ] [ - ] [ - ] [ G ] [ - ]
		[ 1 ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 1 ] [ 2 ] [ 3 ] [ - ] [ 7 ] [ 8 ]       [ G ] [ G ] [ G ] [ - ] [ G ] [ - ] 
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 2 ] [ 3 ] [ 4 ] [ 5 ] [ 6 ] [ 7 ]       [ - ] [ - ] [ G ] [ G ] [ G ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 3 ] [ 4 ] [ - ] [ - ] [ - ] [ 8 ]       [ - ] [ - ] [ - ] [ - ] [ - ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 4 ] [ 5 ] [ 6 ] [ 7 ] [ 8 ] [ - ]       [ - ] [ - ] [ - ] [ - ] [ - ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 5 ] [ 6 ] [ - ] [ 8 ] [ 9 ] [ - ]       [ - ] [ - ] [ - ] [ - ] [ - ] [ - ] 

	Why "amoeba"? - See Boulder Dash... */

#include <iostream>
#include <iomanip>

using namespace std;

int main(int ac, char** av) {
    srand(time(NULL));

    int r_max = 9;
    int c_max = 9;
    int m_max = 9; // maximal marble's number

    int m5array[r_max][c_max], path_array[r_max][c_max];
    // clear both arrays
    for (int r = 0; r < r_max; r++) {
        for (int c = 0; c < c_max; c++) {
            m5array[r][c] = 0;
            path_array[r][c] = 0;
        }
    }

    // spread cx_max marbles on the m5array[][] randomly (no collisions allowed);
    // cx_max+1'th one is a destination place, wile cx_max'th is the last marble put on board

    int cx_max = 30;
    int rr, rc;
    int ir, ic; // origin
    int fr, fc; // destination

    int cx = 1;

    do {
        rr = rand() % r_max; // [0] .. [r_max - 1]
        rc = rand() % c_max;

        if (m5array[rr][rc] == 0) {
            m5array[rr][rc] = 1 + rand() % m_max;
            // if the cell is empty, put the marble there and increase the counter
            cx++;
            if (cx == cx_max) {
                // second-to-last marble holds the origin cell
                ir = rr;
                ic = rc;
                path_array[ir][ic] = 1; // origin
            }
        }
    } while (cx <= cx_max + 1);

    fr = rr;
    fc = rc;
    m5array[fr][fc] = 0;

    for (int r = 0; r < r_max; r++) {
        cout << "\n"; // On-Terminal array's formatted printout
        for (int c = 0; c < c_max; c++) {
            if ((r == fr) && (c == fc)) {
                cout << "F ";
            } else
                if ((r == ir) && (c == ic)) {
                    cout << "I ";
                } else {
                    cout << m5array[r][c] << " ";
                }
        }
    }
    cout << "\n\n";

    // a path between the origin and the destination will be drawn, if possible
    // if not, (cells turn red) an appropriate message is printed

    int present_step = 1;	

    int flag_1 = 0; // reset: 0 = no [f] hit
    int flag_2 = 1;
    do { // amoeba dev. :)
        flag_2 = 0; // reset: 0 = no changes in path_array[][] were made

        for (int r = 0; r < r_max; r++) {
            for (int c = 0; c < c_max; c++) {
                if (path_array[r][c] == present_step) {
                    if (r > 0) {
                        if (m5array[r - 1][c] == 0) {
                            if ((r - 1 == fr) && (c == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r - 1][c] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r - 1][c] = present_step + 1;
                            }
                        }
                    }
                    if (c > 0) {
                        if (m5array[r][c - 1] == 0) {
                            if ((r == fr) && (c - 1 == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r][c - 1] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r][c - 1] = present_step + 1;
                            }
                        }
                    }
                    if (r < r_max - 1) {
                        if (m5array[r + 1][c] == 0) {
                            if ((r + 1 == fr) && (c == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r+1][c] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r + 1][c] = present_step + 1;
                            }
                        }
                    }
                    if (c < c_max - 1) {
                        if (m5array[r][c + 1] == 0) {
                            if ((r == fr) && (c + 1 == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r][c + 1] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r][c + 1] = present_step + 1;
                            }
                        }
                    }
                }
            }
        } // for, for...
        present_step++;
    } while ((flag_1 == 0) && (flag_2 == 1));

    // show path_array[][]
    for (int r = 0; r < r_max; r++) { cout << endl;
        for (int c = 0; c < c_max; c++) {
            if ((r == fr) && (c == fc)) {
                cout << " F  ";
            } else {
                cout << setfill(' ') << setw(2) <<  path_array[r][c] << "  ";
            }
        }
    }
    cout << "\n\n";

    // flag_1 = 1 => hit [f], otherwise there is no valid path!

    if (flag_1 == 1) {
        int r = fr; // start at [f]
        int c = fc;

        path_array[r][c] = -1;

        for (int step = present_step; step > 1; step--) {
            if ((r > 0) && (path_array[r-1][c] == step - 1)) {
                path_array[--r][c] = -1;
            } else
                if ((r < r_max - 1) && (path_array[r+1][c] == step - 1)) {
                    path_array[++r][c] = -1;
                } else
                    if ((c > 0) && (path_array[r][c-1] == step - 1)) {
                        path_array[r][--c] = -1;
                    } else
                        if ((c < c_max - 1) && (path_array[r][c+1] == step - 1)) {
                            path_array[r][++c] = -1;
                        }
        }
    } else {
        cout << "THERE IS NO VALID PATH!\n\n"; // [i] and [f] shall turn red!
    }

    // show path_array[][] with the path marked with "-1"
    for (int r = 0; r < r_max; r++) {
        cout << endl;
        for (int c = 0; c < c_max; c++) {
            cout << setfill(' ') << setw(2) << path_array[r][c] << "  ";
        }
    }
    cout << "\n\n";

    #ifdef WIN32
    system("PAUSE");
    #endif

    return 0;
}
