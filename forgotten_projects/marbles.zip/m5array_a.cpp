// 20130228
// wojciech bruzda
//
// GRAPHICAL REPRESENTATION OF THE m5_array.cpp SOLUTION

#include <iostream>
#include <iomanip>

#include <allegro.h>

using namespace std;

int main(int ac, char** av) {
    srand (time(NULL));

    int r_max = 9;
    int c_max = 9;

    int m_max = 9; // maximum marble's number

    int m5array[r_max][c_max], path_array[r_max][c_max];
    for (int r = 0; r < r_max; r++) {
        for (int c = 0; c < c_max; c++) {
            m5array[r][c] = 0;
            path_array[r][c] = 0;
        }
    }

    // spread cx_max marbles on the m5array[][] randomly (no collisions allowed);
    // cx_max+1'th one is a destination place, wile cx_max'th is the last marble put on board

    int cx_max = 30;

    int rr, rc;
    int ir, ic; // origin
    int fr, fc; // destination

    int cx = 1;
    do {
        rr = rand() % r_max; // [0] .. [r_max - 1]
        rc = rand() % c_max;
        if (m5array[rr][rc] == 0) {
            m5array[rr][rc] = 1 + rand() % m_max;
            // if the cell is empty, put marble there and increase the counter
            cx++;
            if (cx == cx_max) {
            // second-to-last marble holds the origin cell
                ir = rr;
                ic = rc;
                path_array[ir][ic] = 1; // origin
            }
        }
    } while (cx <= cx_max + 1);

    // after the loop ends, the rr and rc are the coordinates of the last marble put on the board
    // let it be a randomly picked empty cell - a destination :)
    // hence, the m5array[rr][rc] must be cleared:

    fr = rr;
    fc = rc;
    m5array[fr][fc] = 0;
    // a path between the origin and the destination will be drawn, if possible
    // if not, (cells turn red) an appropriate message is printed

    int present_step = 1;

    int flag_1 = 0; // reset: 0 = no [f] hit
    int flag_2 = 1;
    do { // amoeba development :)
        flag_2 = 0; // reset: 0 = no changes in path_array[][] were made

        for (int r = 0; r < r_max; r++) {
            for (int c = 0; c < c_max; c++) {
                if (path_array[r][c] == present_step) {
                    if (r > 0) {
                        if (m5array[r - 1][c] == 0) {
                            if ((r - 1 == fr) && (c == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r - 1][c] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r - 1][c] = present_step + 1;
                            }
                        }
                    }
                    if (c > 0) {
                        if (m5array[r][c - 1] == 0) {
                            if ((r == fr) && (c - 1 == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r][c - 1] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r][c - 1] = present_step + 1;
                            }
                        }
                    }
                    if (r < r_max - 1) {
                        if (m5array[r+1][c] == 0) {
                            if ((r + 1 == fr) && (c == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r + 1][c] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r + 1][c] = present_step + 1;
                            }
                        }
                    }
                    if (c < c_max - 1) {
                        if (m5array[r][c + 1] == 0) {
                            if ((r == fr) && (c + 1 == fc)) {
                                flag_1 = 1; // [f] hit, leave the loop
                                break;
                            } else if (path_array[r][c + 1] == 0) {
                                flag_2 = 1; // path_array[][] updated, keep going
                                path_array[r][c + 1] = present_step + 1;
                            }
                        }
                    }
                }
            }
        } // for, for...
        present_step++;
    } while ((flag_1 == 0) && (flag_2 == 1));

    allegro_init();
    install_keyboard();
    set_color_depth(16);
    set_gfx_mode(GFX_AUTODETECT_WINDOWED, 800, 600, 0, 0);
    clear_to_color(screen, makecol(0, 0, 0));

    int cell_size = 50;
    int scale = 60;

    // flag_1 = 1 => hit [f], otherwise there is no valid path!

    if (flag_1 == 1) {
        int r = fr; // start at [f]
        int c = fc;
        path_array[r][c] = -1;

        for (int step = present_step; step > 1; step--) {
            if ((r > 0) && (path_array[r-1][c] == step - 1)) {
                path_array[--r][c] = -1;
            } else
                if ((r < r_max - 1) && (path_array[r+1][c] == step - 1)) {
                    path_array[++r][c] = -1;
                } else
                    if ((c > 0) && (path_array[r][c-1] == step - 1)) {
                        path_array[r][--c] = -1;
                    } else
                        if ((c < c_max - 1) && (path_array[r][c+1] == step - 1)) {
                            path_array[r][++c] = -1;
                        }
        }

        // show path_array[][] with the path marked with "-1"
        for (int r = 0; r < r_max; r++) {
            for (int c = 0; c < c_max; c++) {
                if (m5array[r][c] != 0) {
                    circlefill(
                        screen,
                        (r * scale) + cell_size / 2,
                        (c * scale) + cell_size / 2,
                        cell_size / 2,
                        makecol(m5array[r][c] * 20, (m5array[r][c] * 42) % 255, 111));
                } else {
                    rectfill(
                        screen,
                        (r * scale),
                        (c * scale),
                        (r * scale) + cell_size,
                        (c * scale) + cell_size,
                        makecol(11, 11, 11));
                }
                if (path_array[r][c] == -1) {
                    rectfill(
                        screen,
                        (r * scale),
                        (c * scale),
                        (r * scale) + cell_size,
                        (c * scale) + cell_size,
                        makecol(0, 255, 0));
                }
            }
        }
        circlefill(
            screen,
            (ir * scale) + cell_size / 2,
            (ic * scale) + cell_size / 2,
            cell_size / 2,
            makecol(10, 25, 111));
    } else {
        // NO VALID PATH! [I] and [F] turn red.
        for (int r = 0; r < r_max; r++) {
            for (int c = 0; c < c_max; c++) {
                if (m5array[r][c] != 0) {
                    circlefill(
                        screen,
                        (r * scale) + cell_size / 2,
                        (c * scale) + cell_size / 2,
                        cell_size / 2,
                        makecol(m5array[r][c] * 20, (m5array[r][c] * 42) % 255, 111));
                } else {
                    rectfill(
                        screen,
                        (r * scale),
                        (c * scale),
                        (r * scale) + cell_size,
                        (c * scale) + cell_size,
                        makecol(11, 11, 11));
                }
            }
        } // for, for

        rectfill(
            screen,
            (fr * scale),
            (fc * scale),
            (fr * scale) + cell_size,
            (fc * scale) + cell_size,
            makecol(255, 0, 0));
        rectfill(
            screen,
            (ir * scale),
            (ic * scale),
            (ir * scale) + cell_size,
            (ic * scale) + cell_size,
            makecol(255, 0, 0));
        circlefill(
            screen,
            (ir * scale) + cell_size / 2,
            (ic * scale) + cell_size / 2,
            cell_size / 2,
            makecol(10, 25, 111));
    } // else

    readkey();
    allegro_exit();

    return 0;
}
END_OF_MAIN()
