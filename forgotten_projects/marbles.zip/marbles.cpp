/*      +++++++++++++++
        +             +
        +   MARBLES   +
        +             +
        +++++++++++++++

        wojciech bruzda        

        20130226 : [0012] I am bored, let me write a simple game!
        20130227 : [0012] path finder (radial flow)
        20130228 : [0012] allegro.h: m5_array.cpp ---> m5array_a.cpp
        20130304 : [0022] "text-oriented" m5array.cpp
        20130305 : [0012] bug fixes in m5_print()
        20130306 : [0022] region_modification_2x2_3x3 idea - abandoned * m5_5_seeker(); -> m5_line_seeker();
        20130307 : [0012] cutting a segment: horizontal and vertical and no diagonal yet...
        20130308 : [0005] minor changes
        20130309 : [0005] reading marbles from bitmaps - switched to GEMS as a side project
        20130330 : [0005] refactoring
        20130402 : [0005] refactoring + "a421cgb_m5.hpp" included [based on the GEMS project]
        20130403 : [0005] diagonal segments investigation -- ACTUALLY IT IS STILL FUCKED UP!

        ALLEGRO OPTIONS for DEV-C++ 4.9.9.2
        -----------------------------------
        When callin compiler:
                -DALLEGRO_STATICLINK
        When callin linker:
                -lalleg_s -lgdi32 -ldxguid -lole32 -ldinput -lddraw -lwinmm -ldsound
                check box: Do not create a console window

        TO BE DONE:
        1. tracing the path
        2. diagonal_seeker

        */

///////////////////////////////////////////////////////////////////////////////

//
// game specifications
//
#define _cell_size 60;
#define _cell_space 2;
#define _x_origin 22;
#define _y_origin 22;

#define _segment_length 5; // how many marbles must be aligned to disappear

const char * GAME_WINDOW_CAPTION = "MARBLES | ver. 20130403 | wojciech bruzda";

const int sx_size = 600; // screen size for ALLEGRO
const int sy_size = 600;

////////////////////////////////////////////////////////////////////////////////

#include "a421cgb_m5.hpp"

////////////////////////////////////////////////////////////////////////////////

class m5 : public GAME_BOARD {
    int score;

    int r_max;
    int c_max;

    int m_max;

    int empty_cells;

    // player gets extra turn when successfully removes at least 5 marbles
    bool extra_turn;

    // m*.bmp files of marbles have size: 61x61 pixels,
    // so to be consistent with the game dimensionalities
    // the following constant should be CONSTANT!
    int cell_i; // origin: the cell occupied by a marble
    int cell_f; // destination cell of the marble

    // minimum number of marbles that disappear when aligned
    int segment_length;

public:
    void cell_activation(int, int);
    void path_operation();

    bool m5_path();
    void PLAY();
    void toggle_mode();
    void m5_line_seeker();
    int  spread_marbles(int);
    void RESET();
    m5();
   ~m5() {};
};

m5::m5() {
    r_max = 9;
    c_max = 9;

    segment_length = _segment_length;

    std::srand(std::time(0));
}

void m5::RESET() {
    cell_i = -1; // reset value...
    cell_f = -1;

    // m_max = _m_max;

    set_ac(-1);
    score = 0;

    empty_cells = r_max * c_max;

    for (int i=0; i<r_max*c_max; i++) {
        set_value(i, 0); // clear GAME_ARRAY[] before spread first marbles
    }

    int empty_cells = spread_marbles(3);
    draw();
}

// try to "m_counter" marbles at random on the board
int m5::spread_marbles(int m_counter) {
    if (empty_cells < m_counter) {
        m_counter = empty_cells;
    }

    int m = 0;
    while (m < m_counter) {
        int cell_index = rand() % (r_max * c_max); // [0] .. [r_max * c_max - 1]
        if (get_value(cell_index) == 0) {
            set_value(cell_index, 1 + rand() % m_max);
            m++; // if the cell is empty, put the marble there and increase the counter
        }
    }

    return (empty_cells -= m); // return the number of empty cells
}

void m5::toggle_mode() {
    while (!key[KEY_ESC]) {
        if (close_button_pressed == 1) { break; }
        if (key[KEY_5]) { m_max = 5; RESET(); PLAY(); rest(200); clear_keybuf(); }
        if (key[KEY_6]) { m_max = 6; RESET(); PLAY(); rest(200); clear_keybuf(); }
        if (key[KEY_7]) { m_max = 7; RESET(); PLAY(); rest(200); clear_keybuf(); }
        if (key[KEY_8]) { m_max = 8; RESET(); PLAY(); rest(200); clear_keybuf(); }
        if (key[KEY_9]) { m_max = 9; RESET(); PLAY(); rest(200); clear_keybuf(); }
        blit(
            screen_game_01,
            screen_buffer,
            0, 0, 0, 0,
            screen_game_01 -> w,
            screen_game_01 -> h);
        blit(
            screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
    }
}

void m5::PLAY() {
    int allegro_mx = 0, allegro_my = 0, allegro_mb = 0; // allegro: mouse [x], [y] and its [b]utton

    while (!key[KEY_ESC]) {
        if (key[KEY_SPACE]) { clear_keybuf(); rest(155); RESET(); }
        if (close_button_pressed == 1) { break; }
        textprintf_ex(screen_buffer, font, 22, 8, makecol(200, 200, 200), - 1, "score: %d", score);
        if (allegro_mx != mouse_x || allegro_my != mouse_y || allegro_mb != mouse_b) {
            allegro_mx = mouse_x;
            allegro_my = mouse_y;
            allegro_mb = mouse_b;
        }

        cell_hover(allegro_mx, allegro_my);

        if (allegro_mb == 1) {
            while (allegro_mb == mouse_b) {} // prevent dragging mouse when mouse button is down
            cell_activation(allegro_mx, allegro_my);
            path_operation();
            draw();
            clear_keybuf();
        }

        if (empty_cells == 0) break;

        blit(screen_buffer, screen, 0, 0, 0, 0, sx_size, sy_size);
    }
}

void m5::cell_activation(int mx, int my) {
    for (int cell_index = 0; cell_index < r_max * c_max; cell_index++) {
        // if the mouse cursor is detected within the border of a particular cell when "LEFT MOUST BUTTON DOWN"
        // then the cell should be marked as active (different colour)
        // provided that the the marble is sitting there (if there is no marble, no activation shall be performed)
        if ((get_cx(cell_index) < mx) && (mx < get_cx(cell_index) + cell_size) &&
            (get_cy(cell_index) < my) && (my < get_cy(cell_index) + cell_size)) {
            if ((get_value(cell_index) != 0) | (cell_i != -1)) {
                set_ac(cell_index);
                break;
            } else {
                set_ac(-1);
                break;
            }
        }
    }
}

void m5::path_operation() {
    int ac = get_ac();
    if (cell_i == -1) { // cell_i: unset
        if ((ac != -1) && (get_value(ac) != 0)) { // first part of the AND - is it necessary?
            cell_i = ac;
        }
    } else { // cell_i != -1: cell_i is already set, that means the player has clicked on the cell occupied by the marble
        if ((ac != -1) && (get_value(ac) == 0)) {
            cell_f = ac;
        } else {
            cell_i = ac; // user has changed her mind and picked another marble (or the same cell)
        }
    }

    if ((cell_i != -1) && (cell_f != -1)) { // both are set
        if (m5_path() == true) { // path exists!
            std::cout << "valid path!\n\n";
            set_value(cell_f, get_value(cell_i));
            set_value(cell_i, 0);
            m5_line_seeker();
            if (extra_turn == false) {
                if (empty_cells != 0) {
                    empty_cells = spread_marbles(3);
                    m5_line_seeker();
                }
            }
        // GREEN...
        } else { // path doesn't exist...
            std::cout << "invalid path!\n\n";
            rest(64);
        }
        cell_i = -1;
        cell_f = -1; // reset origin and destination
        rest(64); // must be waiting!!
    }
}

/*	Path preparation:
	-----------------
	The path can go only horizontally or vertically - diagonal direction is excluded.
	An additional path_array[][] is prepared with ONE at the origin: path_array[ir][ic] = 1.

	Let present_step = 1.

	In each step of the loop the empty cells adjacent to the ones with value = present_step
	are given the value = present_step + 1:

	path_array[r][c] = present_step =>
		{
		path_array[r-1][c] = present_step + 1 // provided that path_array[r+-...][c+-...] is valid...
		path_array[r][c+1] = present_step + 1
		path_array[r+1][c] = present_step + 1
		path_array[r][c-1] = present_step + 1
		}

	The loop goes either until it reaches the cell indexed by [fr, fc] or it is impossible
	to increase the value of the present_step. In the latter case the path cannot be constructed
	and the procedure fails.

	Anyway, if the destination [f] is reachable, another loop starts at [f] and
	goes to [i] tracing the descending numbers from the last value of the present_step
	down to 2 - the origin itself. The cells that the loop goes through are marked "green" and
	the path is being established.

		EXAMPLE:

		m5array:
		[ 1 ] [ - ] [ - ] [ F ] [ - ] [ 3 ]
		[ 2 ] [ 3 ] [ 2 ] [ - ] [ - ] [ 4 ]
		[ I ] [ - ] [ - ] [ 3 ] [ - ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]
		[ - ] [ - ] [ 3 ] [ 4 ] [ 1 ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ 3 ]
		[ - ] [ - ] [ 2 ] [ - ] [ - ] [ 7 ]


		path_array: [G for "GREEN" = -1]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ] ----> [ - ] [ - ] [ - ] [ F ] [ 9 ] [ - ] ----> [ - ] [ - ] [ - ] [ G ] [ G ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ - ] [ - ] [ - ] [ 9 ] [ 8 ] [ - ]       [ - ] [ - ] [ - ] [ - ] [ G ] [ - ]
		[ 1 ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 1 ] [ 2 ] [ 3 ] [ - ] [ 7 ] [ 8 ]       [ G ] [ G ] [ G ] [ - ] [ G ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 2 ] [ 3 ] [ 4 ] [ 5 ] [ 6 ] [ 7 ]       [ - ] [ - ] [ G ] [ G ] [ G ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 3 ] [ 4 ] [ - ] [ - ] [ - ] [ 8 ]       [ - ] [ - ] [ - ] [ - ] [ - ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 4 ] [ 5 ] [ 6 ] [ 7 ] [ 8 ] [ - ]       [ - ] [ - ] [ - ] [ - ] [ - ] [ - ]
		[ - ] [ - ] [ - ] [ - ] [ - ] [ - ]       [ 5 ] [ 6 ] [ - ] [ 8 ] [ 9 ] [ - ]       [ - ] [ - ] [ - ] [ - ] [ - ] [ - ] */

bool m5::m5_path() {
    int * path_array = new int[r_max * c_max];

    for (int cell_index = 0; cell_index < r_max * c_max; cell_index++) {
        path_array[cell_index] = 0;
    }

    int present_step = path_array[cell_i] = 1;

    int flag_1 = 0; // reset: 0 = no [f] hit
    int flag_2 = 1;
    do {
        flag_2 = 0; // reset: 0 = no changes in path_array[] were made

        for (int cell_index = 0; cell_index < r_max * c_max; cell_index++) {
            if (path_array[cell_index] == present_step) {
                // general prototype:
                //
                // for (dir = 0; dir < 3; dir++) {
                //     if (f(cell_index, dir))
                // }
                if (cell_index / c_max > 0) {
                    if (get_value(cell_index - c_max) == 0) {
                        if (cell_index - c_max == cell_f) {
                            flag_1 = 1; // [f] hit, leave the loop
                            break;
                        } else if (path_array[cell_index - c_max] == 0 ) {
                            flag_2 = 1; // path_array[] updated, keep going
                            path_array[cell_index - c_max] = present_step + 1;
                        }
                    }
                }
                if (cell_index % c_max > 0) {
                    if (get_value(cell_index - 1) == 0) {
                        if (cell_index - 1 == cell_f) {
                            flag_1 = 1; // [f] hit, leave the loop
                            break;
                        } else if (path_array[cell_index - 1] == 0) {
                            flag_2 = 1; // path_array[] updated, keep going
                            path_array[cell_index - 1] = present_step + 1;
                        }
                    }
                }
                if (cell_index / c_max < r_max - 1) {
                    if (get_value(cell_index + c_max) == 0) {
                        if (cell_index + c_max == cell_f) {
                            flag_1 = 1; // [f] hit, leave the loop
                            break;
                        } else if (path_array[cell_index + c_max] == 0) {
                            flag_2 = 1; // path_array[] updated, keep going
                            path_array[cell_index + c_max] = present_step + 1;
                        }
                    }
                }
                if (cell_index % c_max < c_max - 1) {
                    if (get_value(cell_index + 1) == 0) {
                        if (cell_index + 1 == cell_f) {
                            flag_1 = 1; // [f] hit, leave the loop
                            break;
                        } else if (path_array[cell_index + 1] == 0) {
                            flag_2 = 1; // path_array[] updated, keep going
                            path_array[cell_index + 1] = present_step + 1;
                        }
                    }
                }
            }
        } // for...
        present_step++;
    } while ((flag_1 == 0) && (flag_2 == 1));
    // only needed when tracing the path..
    // flag_1 = 1 => hit [f], otherwise there is no valid path!
    if (flag_1 == 1) {
        int cell_index = cell_f; // start at [f]
        path_array[cell_index] = -1;
        for (int step = present_step; step > 1; step--) {
            if ((cell_index / c_max > 0) && (path_array[cell_index - c_max] == step - 1)) {
                path_array[cell_index -= c_max] = -1;
            } else
                if ((cell_index / c_max < r_max - 1) && (path_array[cell_index + c_max] == step - 1)) {
                    path_array[cell_index += c_max] = -1;
                } else
                    if ((cell_index % c_max > 0) && (path_array[cell_index - 1] == step - 1)) {
                        path_array[cell_index -= 1] = -1;
                    } else
                        if ((cell_index % c_max < c_max - 1) && (path_array[cell_index + 1] == step - 1)) {
                            path_array[cell_index += 1] = -1;
                        }
        }
    } else {
        // std::cout << "THERE IS NO VALID PATH!\n\n"; // [i] and [f] shall turn red!
        delete[] path_array; // XXX DRY!
        return false;
    }

    // XXX
    // not sure, but i think once that I saw the:
    //                -1 -1
    //                -1 -1 pattern, in tests, which is rather impossible - CHECK IT!!

    delete[] path_array;

    return true;
}

//      ROUGH SCHEME: // fucking mess in the code and description, to be fixed...
//
//      m5_array is GAME_ARRAY (after reorganisation...)
//
//      First it scans rows, then columns, and eventually left- and
//      right-oriented sub-diagonals.
//
//      ROWS:
//      Each row of the m5_array[] is being considered
//      individually (separately). Each [fixed] marble number corresponds
//      to +1 value whilst for any other marbles [not fixed at a moment] including
//      empty spaces it is -1.
//
//      pseudo code draft
//      -----------------
//
//      for (int fixed_marble...
//
//          for (int m5_array_r = 0...
//
//              int m5_line = 0;
//              int offset = -1;
//              @nth_row: for (int i = 0; i < c_max; i++) {
//                  if (m5_array[i] == fixed_marble) { m5_line++; if (offset == -1) { offset = i; } }
//                  else { if (m5_line >= 5) { CUT(); } m5_line = 0; offset = -1; }
//              }
//
//              for (int m5_array_c = 0 ...
//
//              for (int m5_array_d = 0 ... // selected sub-diagonals

void m5::m5_line_seeker() {

    // PLAN:
    // 1. horizontal lines
    // 2. vertical...
    // 3. selected sub-diagonals...

    /* 1 */
    for (int fixed_marble = 1; fixed_marble <= m_max; fixed_marble++) {
        for (int r = 0; r < r_max; r++) {
            int offset = -1;
            int m5_line = 0;
            for (int i = 0; i < c_max; i++) {
                if ((get_value(r * c_max + i) == fixed_marble) ||
                    (get_value(r * c_max + i) == fixed_marble + 10)) {
                    // we need to check that the marble could have been already marked
                    // this justifies the second part of the alternative
                    // however, at the beginning, if we go through the lines, it is no longer needed
                    // BUT, it MUST BE CHECKED in the next steps (after rows have been
                    // checked) - when we scan columns and sub-diagonals!
                    m5_line++;
                    if (offset == -1) {
                        offset = i;
                    }
                } else {
                    if (m5_line >= segment_length) {
// when cutting: +10 shift of the marble value as a mark to be deleted...
//
// 1 1 1 1 1 0 1 0 0 1 0 1 0 2 0 3 1 -> 10 10 10 10 10 0  1  0  0  1  0  1  0  2  0  3  1 -> 0 0 0 0 0 0 1 0 0 1 0 1 0 2 0 3 1
// 1 0 2 1 2 2 2 2 2 2 0 1 0 3 0 2 1    1  0  2  10 2  20 20 20 20 20 0  1  0  3  0  2  1    1 0 2 0 0 0 0 0 2 2 0 1 0 3 0 2 1
// 0 3 0 1 1 0 3 0 1 0 2 0 0 2 2 2 2    0  3  0  10 1  0  3  0  1  0  2  0  0  2  2  2  2    0 3 0 0 1 0 3 0 1 0 2 0 0 2 2 2 2
// 1 2 0 1 0 3 2 0 1 0 0 1 0 3 0 1 2    1  2  0  10 0  3  2  0  1  0  0  1  0  3  0  1  2    1 2 0 0 0 3 2 0 1 0 0 1 0 3 0 1 2
// 0 3 0 1 3 0 0 2 3 0 1 3 3 3 3 3 1    0  3  0  10 3  0  0  2  3  0  1  30 30 30 30 30 1    0 3 0 0 3 0 0 2 3 0 1 0 0 0 0 0 1
//                                      get score somewhere here :)

                        // +10_update:
                        for (int i = r * c_max + offset; i < r * c_max + offset + m5_line; i++) {
                            set_value(i, get_value(i) + 10);
                            // m5_array[i] += 10;
                        }
                        std::cout << "m: " << fixed_marble << ", r: " << r << " "; 
                        std::cout << "cutting a segment of len: " << m5_line << " starting from a relative offset "<< offset << "\n\n";
                    }
                    // reset the segment length and the offset of the segment
                    m5_line = 0;
                    offset = -1;
                }
            }
            // once the row examination is done we must check again for the results
            if (m5_line >= segment_length) {
                // +10_update:
                for (int i = r * c_max + offset; i < r * c_max + offset + m5_line; i++) {
                    set_value(i, get_value(i)+10);
                    // m5_array[i] += 10;
                }
                std::cout << "m: " << fixed_marble << ", r: " << r << " "; 
                std::cout << "cutting a segment of len: " << m5_line << " starting from a relative offset "<< offset << "\n\n";
            }
        } // for (int r...
    } // for (int fixed_marble...

    // here we've collected the information about the potential segments in the lines of m5_array[]
    // now we'll do the same for the columns of m5_array[]

    /* 2 */
    for (int fixed_marble = 1; fixed_marble <= m_max; fixed_marble++) {
        for (int c = 0; c < c_max; c++) {
            int offset = -1;
            int m5_line = 0;
            for (int i = 0; i < r_max; i++) { // now "i" goes vertically (downward)
                if ((get_value(c + i * c_max) == fixed_marble) ||
                    (get_value(c + i * c_max) == fixed_marble + 10)) {
                    m5_line++;
                    if (offset == -1) {
                        offset = i;
                    }
                } else {
                    if (m5_line >= segment_length) {
                        // +10_update:
                        // for (int i = c + c_max * offset; i < c + c_max * offset + m5_line; i++)
                        for (int i = 0; i < m5_line; i++) {
                            if (get_value(c + offset * c_max + i * c_max) < 10) { // or modulo 20?
                                set_value(c + offset * c_max + i * c_max, get_value(c + offset * c_max + i * c_max) + 10);
                                // m5_array[c+offset*c_max + i*c_max] += 10;
                            }
                        }
                        // std::cout << "m: " << fixed_marble << ", c: " << c << " ";
                        // std::cout << "cutting a segment of len: " << m5_line << " starting from "<< offset << "\n\n";
                    }
                    // reset the segment length and the offset of the segment
                    m5_line = 0;
                    offset = -1;
                }
            }
            if (m5_line >= segment_length) {
                // +10_update:
                // for (int i = c + c_max * offset; i < c + c_max * offset + m5_line; i++)
                for (int i = 0; i < m5_line; i++) {
                    if (get_value(c+offset*c_max+i*c_max) < 10) {
                         // it might have already been added in the previous step when working with rows
                        set_value(c + offset * c_max + i * c_max, get_value(c + offset * c_max + i * c_max) + 10);
                        // m5_array[c+offset*c_max + i*c_max] += 10;
                    }
                }
                // std::cout << "m: " << fixed_marble << ", c: " << c << " ";
                // std::cout << "cutting a segment of len: " << m5_line << " starting from "<< offset << "\n\n";
            }
        } // for (int c...
    } // for (int fixed_marble...

    // and eventually for the subdiagonals
    /* 3 */ // and then /* 3' */ - sub-antidiagonals...
    // TO BE DONE IN A FUTURE...

    // go through the m5_array[], get all +10 values, set them to zero, counting
    // them down to collect the score :)
    // get x points for each marble number = x, eg:
    //
    //    0 2 0 1 1 1 1 1 1
    //    0 2 0 1 0 0 0 0 0
    //    0 2 0 1 0 0 0 0 0 -> when this configuration is present
    //    0 2 0 1 0 0 0 0 0 -> user gets 2*5 + 10*1 = 20 points of score
    //    0 2 0 1 0 0 0 0 0

    extra_turn = false;

    for (int i = 0; i < r_max * c_max; i++) {
        if (get_value(i) > 10) {
            set_value(i, get_value(i)-10);
            score += get_value(i);
            set_value(i, 0);
            empty_cells++; // update information about the free space on the board
            extra_turn = true;
            set_ac(-1); // reset active_cell
        }
    }
}

////////////////////////////////////////////////////////////////////////////////
int main(int ac, char** av) {
    m5 MARBLES;

    MARBLES.toggle_mode();
    return 0;
}
END_OF_MAIN()
////////////////////////////////////////////////////////////////////////////////

