<!--
 It is FUCKED UP - TO BE FIXED!!!

 Squares (tiles) are initially distributed randomly (no overlapping) on the screen with numbers from 1 to n (n =< 16).
 After k seconds (or on demand) numbers hide and squares turn to be blank.
 The task is to click out the squares in order they have been numbered.
 After correct click a tile dissapears.
 After wrong click the game is over.

 One-Day-Project inspired by Alex the Gray Parrot and an unnamed monkey who knew how to play... -->

<?php

// I MUST HAVE BEEN HIGH ON SLEEP DEPRIVATION PREPARING THIS SHIT...

require_once("TS_HTMLView.php");
require_once("TS_Game.php");
$numberOfTiles = 8;
$tileSide = 40; // in pixels
new HTMLView($numberOfTiles);
$game = new Game($numberOfTiles, $tileSide);
?>

