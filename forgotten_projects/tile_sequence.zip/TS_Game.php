<?php
require_once("TS_Tile.php");

final class Game {

    private $tileSide;
    private $numberOfTiles;
    private $tiles;

    public function __construct($numberOfTiles, $tileSide) {
        $this->numberOfTiles = $numberOfTiles;
        $this->tileSide = $tileSide;
        $this->tiles = array();
        $this->resetTiles();
    }

    // scatter tiles randomly on the game area
    private function resetTiles() {
        $tileNumber = $this->numberOfTiles;
        while ($tileNumber) {
            $x = rand(($this->tileSide / 2) + 1, 800 - ($this->tileSide / 2) - 1);
            $y = rand(($this->tileSide / 2) + 200, 600 - ($this->tileSide / 2) - 1);

            // TODO: seed should be called once!
            // TODO: maximumAttempts needed here!
            if (!$this->tileCollides($x, $y)) {
                $tile = new Tile($x, $y, $tileNumber, $this->tileSide);
                array_push($this->tiles, $tile);
                $tileNumber--;
            }
        }
        foreach ($this->tiles as $tile) {
            $tile->showTile();
        }
    }

    // new tile parameters must not collide (overlap) with current objects
    private function tileCollides($x, $y) {
        foreach ($this->tiles as $tile) {
            if (abs($tile->getX() - $x) <= $this->tileSide ||
                abs($tile->getY() - $y) <= $this->tileSide) {
                return true;
            }
        }
        return false;
    }

}

?>

