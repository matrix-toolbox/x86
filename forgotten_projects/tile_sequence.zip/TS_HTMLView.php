<?php
class HTMLView {
    public function __construct($numberOfTiles) {
        echo "<!DOCTYPE html>\n";
        echo "<meta charset=\"UTF-8\">\n";
        echo "<link rel=\"icon\" type=\"image/x-icon\" href=\"index.gif\">\n";
        echo "<title>tile sequence</title>\n";
        echo "<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js'></script>\n";
        echo "<script>var s = '';</script>\n";
        for ($t = 1; $t <= $numberOfTiles; $t++) {
            echo "<script> $(document).ready(function(){ $('#x".$t."').click(function(){ $('#x".$t."').hide(); s=s+'".$t."'; checkSequence(); }); });</script>\n";
        }
        echo "<script>function checkSequence() { for (var i = 0; i < s.length; i++) { if (s[i] != i + 1) {
              document.getElementById('message').innerHTML = 'Not so good! Refresh browser to continue.'; ";
        for ($t = 1; $t <= $numberOfTiles; $t++) {
            echo "$(document).ready(function(){  $('#x".$t."').hide(); });\n";
        }
        echo "} if (i == $numberOfTiles - 1) { document.getElementById('message').innerHTML = 'Good! Refresh browser to continue.'; } } }</script>\n";
        echo "<h1>sequences</h1>\n";
        echo "<hr>\n";
        echo "<p onClick='hideNumbers()' id='message'>click this message to hide the numbers and then click out the tiles in ascending order</p>\n";
        echo "<script>function hideNumbers() {";
        for ($t = 1; $t <= $numberOfTiles; $t++) {
            echo "document.getElementById('x".$t."').style.color = '#ccc';\n";
        }
        echo "}</script>\n";
        echo "<hr>\n";
        echo "<p>2017 &bull; 09 &bull; 02 &bull; <a href=\"index.html\">wojciech bruzda</a></p>\n";
    }

    public static function drawRectangle($x, $y, $side, $text) {
        $top = $y - ($side / 2);
        $left = $x - ($side / 2);
        // line-height is needed for vertical text alignment
        echo "<div id='x".$text."' style='position: absolute; top: ".$top."px; left: ".$left."px; background-color: #ccc; width: ".$side."px; height: ".$side."px; text-align: center; vertical-align: middle; line-height: ".$side."px; border-radius: 5px;'>".$text."</div>\n";  
    }

}

