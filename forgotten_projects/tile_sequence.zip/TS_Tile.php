<?php
require_once("TS_HTMLView.php");

final class Tile {
    private $x; // (x, y) = tile center!
    private $y;
    private $tileNumber;
    private $tileSide;

    public function __construct($x, $y, $tileNumber, $tileSide) {
        $this->x = $x;
        $this->y = $y;
        $this->tileNumber = $tileNumber;
        $this->tileSide = $tileSide;
    }

    public function getX() {
        return $this->x;
    }

    public function getY() {
        return $this->y;
    }

    public function showTile() {
        HTMLView::drawRectangle($this->x, $this->y, $this->tileSide, $this->tileNumber);
    }
}


//             y
//
//        +----+----+          }
//        |         |          }
//        |         |          }
// tile:  +    *    + = x      } = tileSide
//        |         |          }
//        |         |          }
//        +----+----+          }

?>
